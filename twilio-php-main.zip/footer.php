<footer class="text-center lg:text-left topbar text-gray-600" style="position:fixed;left:0;bottom:0;width:100%;">
  <div class="text-center p-6">
    <?php 
    $currentyear = date("Y");
    ?>
    <span>©  Copyright: <?php echo $currentyear; ?></span>
    <p class="text-gray-600 font-semibold">Office of the Municipal Agriculturist in Candelaria Quezon</p>
  </div>
</footer>